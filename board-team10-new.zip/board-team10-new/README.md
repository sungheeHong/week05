# Mentoring-Assignment-Intermediate
## ERD
<img src = "./board-team10-erd.png">
